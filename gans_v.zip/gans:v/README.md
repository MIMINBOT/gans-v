### I'm FXC7BOT Gift Me Stars 🌟 <br><img src="https://github.com/TheDudeThatCode/TheDudeThatCode/blob/master/Assets/Hi.gif" width="20px">
<p align="center">
<a href="https://github.com/Fxc7"><img src="https://raw.githubusercontent.com/Fxc7/termux-bot-wa/main/src/glitchtext.png"></a>
</p>
<br>



<p align="center">
<a href="#"><img title="termux-bot-wa" src="https://img.shields.io/badge/-TERMUX--BOT--WA-green?colorA=%23ff0000&colorB=%23017e40&style=for-the-badge"></a>
</p>
<p align="center">
<a href="https://github.com/Fxc7"><img title="Author" src="https://img.shields.io/badge/AUTHOR-FARHAN-orange?style=for-the-badge&logo=github"></a>
</p>
<p align="center">
<a href="https://github.com/Fxc7/followers"><img title="Followers" src="https://img.shields.io/github/followers/Fxc7?color=blue&style=flat-square"></a>
<a href="https://github.com/Fxc7/termux-bot-wa/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/Fxc7/termux-bot-wa?color=red&style=flat-square"></a>
<a href="https://github.com/Fxc7/termux-bot-wa/network/members"><img title="Forks" src="http://img.shields.io/github/forks/Fxc7/termux-bot-wa?color=red&style=flat-square"></a>
<a href="https://github.com/Fxc7/termux-bot-wa/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/Fxc7/termux-bot-wa?label=Watchers&color=blue&style=flat-square"></a>
<a href="https://hits.seeyoufarm.com"><img src="https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https%3A%2F%2Fgithub.com%2FFxc7%2Ftermux-bot-wa&count_bg=%2379C83D&title_bg=%23555555&icon=&icon_color=%23E7E7E7&title=Support&edge_flat=false"/></a>
<a href="#"><img title="MAINTENED" src="https://img.shields.io/badge/MAINTENED-YES-blue.svg"</a>
</p>

<hr color="black">
## I am Hungry Your Donate
<hr color="black">

* [Saweria](https://saweria.co/FarhanXCo)
* [Trakteer](https://trakteer.id/FarhanXCo)


## Tools

```bash
> Termux
> WhatsApp
> 2 HandPhone
```

## Install
Follow The Steps Below!

```bash
> termux-setup-storage
(after that tap on permission)
> pkg update -y
> pkg upgrade -y
> pkg install python -y
> pkg install git -y
> git clone https://github.com/Fxc7/termux-bot-wa
> cd termux-bot-wa
> bash install.sh
> npm start / node Fxc7.js
```

## Features

| NEW USER | YES
| :---------------------------------------------: | :-----------: |
|  Daftar|✅|

|  CREATOR  |                                           YES |
| :---------------------------------------------: | :-----------: |
| Sticker Maker|✅|
| Sticker Gif Maker|✅|
| Convert Sticker To Image|✅|
| Convert Video To MP3|✅|
| Black Pink Logo Maker|✅|
| 3D Text Maker|✅|
| Glitch|✅|
| Quote Maker|✅|
| Water Maker|✅|
| Fire Text Maker
| Marvel Logo Maker|✅|
| Snow Write Maker|✅|
| Ninja Logo Maker|✅|
| Logo Wolf Maker|✅|
| And much more |✅|

| MEDIA | YES |
| :-----------------: | :-------: |
| Trend Twit|✅|
| YT Search|✅|
| Wattpad Search|✅|

| EDUCATION | YES |
| :-----------------: | :-------: |
| The Meaning Of The Name|✅|
| Text To Sticker|✅|
| Nulis Name/class/text|✅|
| Quotes|✅|

| DOWNLOADER | YES |
| :-----------------: | :-------: |
| Pinterest Downloader|✅|

| MEME | YES |
| :-----------------: | :-------: |
| Meme|✅|
| Meme Indo|✅|

| GROUP | YES |
| :-----------------: | :-------: |
| Anti link|✅|
| Open Group|✅|
| Link Group|✅|
| info Group|✅|
| Close Group|✅|
| Promote Member|✅|
| Demote Member|✅|
| Hide Tag|✅|
| Tag All Members|✅|
| Add Member|✅|
| Kick Member|✅|
| Show List Admins|✅|
| Leave Group|✅|
| Show Owner Group|✅|
| welcome New Members|✅|
| Nsfw|✅|

| SOUND | YES |
| :-----------------: | :-------: |
| Text To Speach|✅|

| MUSIC | YES |
| :-----------------: | :-------: |
| Music Lyrics|✅|
| Chord Guitar|✅|

| ISLAM | YES |
| :-----------------: | :-------: |
| Qur'an|✅|
| Qur'an Surah 1,2,3 dll |✅|

| STALK | YES |
| :-----------------: | :-------: |
| Instagram Stalk|✅|
| Tiktok Stalk|✅|

| WIBU | YES |
| :-----------------: | :-------: |
| Neonime|✅|
| Pokemon|✅|
| Nekonime|✅|
| Shota|✅|
| Kaneki|✅|
| Touka chan|✅|
| Naruto|✅|
| Loli|✅|
| Random Shota|✅|
| Random Waifu|✅|
| Random Anime|✅|
| And much more|✅|

| FUN | YES |
| :-----------------: | :-------: |
| Kucing|✅|
| Anjing|✅|
| Alay|✅|
| hilih|✅|
| Cek Ganteng|✅|
| Cantik cek|✅|
| Watak|✅|
| Quotes bucin|✅|
| Kata Cinta|✅|
| Random Hobby|✅|
| Search Image [optional]|✅|
| Pinterest [Optional] |✅|
| Truth Or Dare |✅|
| Dark Jokes|✅|
| Apakah|✅|
| Kapankah|✅|
| Bisakah|✅|
| Rate|✅|

| INFORMATION | YES |
| :-----------------: | :-------: |
| List Bahasa|✅|
| Information Weather|✅|
| KBBI|✅|
| Fakta|✅|
| Covid|✅|
| Gempa Terkini|✅|

| 18+ | YES |
| :-----------------: | :-------: |
| Random Hentai|✅|
| NSFW Neko|✅|
| NSFW Blowjob |✅|
| NSFW Loli|✅|
| NSFW Anime|✅|
| Asupan|✅|

| OWNER | YES |
| :-----------------: | :-------: |
| Add bucin|✅|
| Set pp bot|✅|
| Set Limit Harian|✅|
| Set Limit Member Group|✅|
| Set Reply Chat|✅|
| add premium |✅|
| Banned Member|✅|
| Unbanned Member|✅|
| Block Member|✅|
| Unblock Member|✅|
| remove premium |✅|
| Set Prefix|✅|
| Block Member|✅|
| Broadcast|✅|
| Group Broadcast|✅|
| Clear All Chat|✅|
| Bott aktif/nonaktif|✅|

| PREMIUM MENU | YES |
| :-----------------: | :-------: |
| Youtube mp3 Download|✅|
| Tiktok Downloader|✅|
| Youtube mp4 Download|✅|
| Joox|✅|
| Facebook Video Download|✅|
| Snack Video Download|✅|
| Play Mp3|✅|

 TENTANG BOT | YES |
| :-----------------: | :-------: |
| info|✅|
| Premium List|✅|
| User list|✅|
| Banned list|✅|
| Block list|✅|


## Note

* Dont Forget Stars

* |En| And You can add your own quotes
* |Ind| Dan Kalian Bisa tambahkan Quotes Kalian


## Special Thanks

* <a href="https://github.com/adiwajshing/Baileys"><img alt="GitHub" src="https://img.shields.io/badge/adiwajshing/Baileys%20-%23121011.svg?&style=for-the-badge&logo=github&logoColor=white">
* <a href="https://github.com/MhankBarBar"><img alt="GitHub" src="https://img.shields.io/badge/MhankBarBar%20-%23121011.svg?&style=for-the-badge&logo=github&logoColor=white">
* <a href="https://github.com/nurutomo"><img alt="GitHub" src="https://img.shields.io/badge/nurutomo%20-%23121011.svg?&style=for-the-badge&logo=github&logoColor=white">
* <a href="https://github.com/affisjunianto"><img alt="GitHub" src="https://img.shields.io/badge/affisjunianto%20-%23121011.svg?&style=for-the-badge&logo=github&logoColor=white">
* <img alt="GitHub" src="https://img.shields.io/badge/TEAM FXC7BOT%20-%23121011.svg?&style=for-the-badge&logo=github&logoColor=white">



## Group

* <a href="https://chat.whatsapp.com/GHC5djoQJrcGBJFwYQuQoB"><img alt="WhatsApp" src="https://img.shields.io/badge/WhatsApp%20Group-25D366?style=for-the-badge&logo=whatsapp&logoColor=white"/></a>

---
