const a = '```'
const spam = (prefix, pushname2, groupName, user, name) => {
return `

┏━━°❀❬ *REGULATION* ❭❀°━━┓
┃
┣➥  *NAMA USER :* *${pushname2}*
┣➥  *NAMA GRUP :* *${groupName}*
┣➥  *VERSION :* *0.0.0*
┣➥  *USER TERDAFTAR :* *${user.length} User*
┃
┗━━━━━━━━━━━━━━━━━━

┏━━°❀❬ *SPAMER* ❭❀°━━┓
┃
┣➥  *${prefix}spamcall 083xxxxxxxxx*
┣➥  *${prefix}spamgmail contoh@gmail.com*
┃
┗━━━━━━━━━━━━━━━━━━
`
}
exports.spam = spam