const a = '```'
const others = (prefix, pushname2, groupName, user, name) => {
return `

┏━━°❀❬ *REGULATION* ❭❀°━━┓
┃
┣➥  *NAMA USER :* *${pushname2}*
┣➥  *NAMA GRUP :* *${groupName}*
┣➥  *VERSION :* *0.0.0*
┣➥  *USER TERDAFTAR :* *${user.length} User*
┃
┗━━━━━━━━━━━━━━━━━━

┏━━°❀❬ *OTHERS* ❭❀°━━┓
┃
┣➥  *${prefix}randomexo*
┣➥  *${prefix}randombts*
┣➥  *${prefix}blackpink*
┣➥  *${prefix}anjing*
┣➥  *${prefix}kucing*
┣➥  *${prefix}testime*
┣➥  *${prefix}quotes*
┣➥  *${prefix}katabijak*
┣➥  *${prefix}bucin*
┣➥  *${prefix}bacotandilan*
┣➥  *${prefix}pantun*
┣➥  *${prefix}hekerbucin*
┣➥  *${prefix}katailham*
┃
┗━━━━━━━━━━━━━━━━━━

┏━━°❀❬ *ISLAMIC* ❭❀°━━┓
┃
┣➥  *${prefix}jadwalsholat cilacap*
┣➥  *${prefix}quran*
┣➥  *${prefix}listsurah*
┣➥  *${prefix}quransurah 1*
┃
┗━━━━━━━━━━━━━━━━━━
`
}
exports.others = others