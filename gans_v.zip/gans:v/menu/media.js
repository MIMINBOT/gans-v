const a = '```'
const mediaa = (prefix, pushname2, groupName, user, name) => {
return `

┏━━°❀❬ *REGULATION* ❭❀°━━┓
┃
┣➥   *NAMA USER :* *${pushname2}*
┣➥   *NAMA GRUP :* *${groupName}*
┣➥   *VERSION :* *0.0.0*
┣➥   *USER TERDAFTAR :* *${user.length} User*
┃
┗━━━━━━━━━━━━━━━━━━

┏━━°❀❬ *MEDIA & DONLOAD* ❭❀°━━┓
┃
┣➥ *${prefix}tiktokstalk username*
┣➥ *${prefix}igstalk @username*
┣➥ *${prefix}tiktoksearch dayana*
┣➥ *${prefix}instavid link valid*
┣➥ *${prefix}instaimg link valid*
┣➥ *${prefix}instastory username*
┣➥ *${prefix}ssweb url*
┣➥ *${prefix}url2img Url*
┣➥ *${prefix}tiktok*
┣➥ *${prefix}fototiktok*
┣➥ *${prefix}kbbi*
┣➥ *${prefix}wait*
┃
┗━━━━━━━━━━━━━━━━━━
`
 }

exports.mediaa = mediaa