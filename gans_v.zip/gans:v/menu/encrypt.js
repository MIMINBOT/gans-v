const a = '```'
const encrypt = (prefix, pushname2, groupName, user, name) => {
return `
┏━━°❀❬ *REGULATION* ❭❀°━━┓
┃
┣➥  *NAMA USER :* *${pushname2}*
┣➥  *NAMA GRUP:* *${groupName}*
┣➥  *VERSION :* *10*
┣➥  *USER TERDAFTAR :* *${user.length} User*
┃
┗━━━━━━━━━━━━━━━━━━

┏━━°❀❬ *ENCRYPT & DECRYPT* ❭❀°━━┓
┃
┣➥ *${prefix}encode64 string*
┣➥ *${prefix}decode64 encrypt*
┣➥ *${prefix}hexaencode string*
┣➥ *${prefix}hexadecode encrypt*
┣➥ *${prefix}encbinary string*
┣➥ *${prefix}decbinary encrypt*
┣➥ *${prefix}encoctal string*
┣➥ *${prefix}decoctal encrypt*
┣➥ *${prefix}dorking dork*
┣➥ *${prefix}whois Domain*
┣➥ *${prefix}hostsearch Domain*
┣➥ *${prefix}dnslookup IP/Domain*
┣➥ *${prefix}geoip IP*
┣➥ *${prefix}nping IP*
┣➥ *${prefix}pastebin teks*
┣➥ *${prefix}tinyurl link*
┣➥ *${prefix}bitly link*
┣➥ *${prefix}hashidentifier Encrypt Hash*
┃
┗━━━━━━━━━━━━━━━━━━
`
}
exports.encrypt = encrypt