const a = '```'
const primbon = (prefix, pushname2, groupName, user, name) => {
return `

┏━━°❀❬ *REGULATION* ❭❀°━━┓
┃
┣➥  *NAMA USER :* *${pushname2}*
┣➥  *NAMA GRUP :* *${groupName}*
┣➥  *VERSION :* *0.0.0*
┣➥  *USER TERDAFTAR :* *${user.length} User*
┃
┗━━━━━━━━━━━━━━━━━━

┏━━°❀❬ *PRIMBON MENU* ❭❀°━━┓
┃
┣➥  *${prefix}apakah aku ganteng?*
┣➥  *${prefix}kapankah aku menikah?*
┣➥  *${prefix}bisakah aku memilikimu?*
┣➥  *${prefix}rate reply something*
┣➥  *${prefix}watak Ibnu*
┣➥  *${prefix}hobby Ibnu*
┣➥  *${prefix}gantengcek Ibnu*
┣➥  *${prefix}cantikcek mimin*
┣➥  *${prefix}persengay bayu*
┣➥  *${prefix}pbucin ibnu*
┣➥  *${prefix}mimpi Ular*
┣➥  *${prefix}artinama Ibnu*
┣➥  *${prefix}pasangan nama/nama*
┣➥  *${prefix}tanggaljadian 00/00/0000*
┣➥  *${prefix}zodiak taurus*
┃
┗━━━━━━━━━━━━━━━━━━
` 
}
exports.primbon = primbon