const a = '```'
const menupremium = (prefix, pushname2, groupName, user, name, premium, premi) => {
return `
┏━━°❀❬ *REGULATION* ❭❀°━━┓
┃
┣➥  *NAMA USER :* *${pushname2}*
┣➥  *NAMA GRUP :* *${groupName}*
┣➥  *VERSION :* *0.0.0*
┣➥  *USER TERDAFTAR :* *${user.length} User*
┃
┗━━━━━━━━━━━━━━━━━━

┏━━°❀❬ *PREMIUM ONLY* ❭❀°━━┓
┃
┣➥  *${prefix}playmp3 menepi*
┣➥  *${prefix}fb link video*
┣➥  *${prefix}snack link snack video*
┣➥  *${prefix}ytmp3 link yt*
┣➥  *${prefix}ytmp4 link yt*
┣➥  *${prefix}tiktok link video tiktok*
┣➥  *${prefix}joox Monolog Pamungkas*
┣➥  *${prefix}smule Link Video Smule*
┃
┗━━━━━━━━━━━━━━━━━━
`
}
exports.menupremium = menupremium