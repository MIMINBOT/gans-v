const a = '```'
const informasi = (prefix, pushname2, groupName, user, name) => {
return `
┏━━°❀❬ *REGULATION* ❭❀°━━┓
┃
┣➥   *NAMA USER :* *${pushname2}*
┣➥   *NAMA GRUP :* *${groupName}*
┣➥   *VERSION :* *0.0.0*
┣➥   *USER TERDAFTAR :* *${user.length} User*
┃
┗━━━━━━━━━━━━━━━━━━

┏━━°❀❬ *INFORMATION* ❭❀°━━┓
┃
┣➥ *${prefix}fakta*
┣➥ *${prefix}infogempa*
┣➥ *${prefix}jarak Banyuwangi/Surabaya*
┣➥ *${prefix}translate en/Apa kabar?*
┣➥ *${prefix}bpfont mimin*
┣➥ *${prefix}textstyle Ibnu*
┣➥ *${prefix}jadwaltv antv*
┣➥ *${prefix}jadwaltvnow*
┣➥ *${prefix}lirik melukis senja*
┣➥ *${prefix}chord Melukis senja*
┣➥ *${prefix}wiki Adolf Hitler*
┣➥ *${prefix}brainly pertanyaan*
┣➥ *${prefix}resepmasakan bakwan*
┣➥ *${prefix}map Banyuwangi*
┣➥ *${prefix}film Fast and Farious*
┣➥ *${prefix}pinterest gambar kucing*
┣➥ *${prefix}infocuaca Banyuwangi*
┣➥ *${prefix}jamdunia Banyuwangi*
┣➥ *${prefix}infoalamat jalan Banyuwangi*
┣➥ *${prefix}playstore WhatsApp*
┣➥ *${prefix}moddroid lightroom*
┣➥ *${prefix}happymod lightroom*
┃
┗━━━━━━━━━━━━━━━━━━
`
}
exports.informasi = informasi